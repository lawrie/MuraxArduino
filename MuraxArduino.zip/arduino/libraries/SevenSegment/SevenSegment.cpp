#include "SevenSegment.h"

void
SevenSegmentClass::write(int data) {
  IO_SEVEN_SEGMENT = data;
}

SevenSegmentClass SevenSegment;
