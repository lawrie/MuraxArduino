#include "Quadrature.h"

int
QuadratureClass::read(void) {
  return IO_QUADRATURE_VALUE;
}

QuadratureClass Quadrature;
